export const roles = [
  {
    value: "user",
  },
  {
    value: "admin",
  },
];
