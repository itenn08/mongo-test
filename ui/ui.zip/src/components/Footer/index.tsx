import React from 'react';

const Footer = () => <div>footer component</div>;

export default Footer;
